## Icons under Creative Commons (Attribution-Share Alike 3.0 Unported)
1. Simplicio iconset by [Neurovit](http://rcpktk.deviantart.com/?rnrd=161775)
  - https://www.iconfinder.com/iconsets/simplicio
  - Icons we use(adjusted the color of the icons):
    - media/textures/button_confirm.png
    - media/textures/button_document_new.png
    - media/textures/button_document_open.png
    - media/textures/button_document_save.png
    - media/textures/button_standard_view.png
    - media/textures/point_4.png
    - media/textures/point_3.png

##  MIT License
1. Octicons by GitHub(www.github.com)
  - https://www.iconfinder.com/iconsets/octicons
  - Icons we use(adjusted the color of the icons):
    - media/textures/button_pencil.png
    - media/textures/button_mirror.png

##  Flaticon Basic License http://cdn.flaticon.com/license/license.pdf / Creative Commons BY 3.0
1. Basic Application by [Freepik](http://www.freepik.com/)
  - www.flaticon.com/packs/basic-application/
  - Icons we use(adjusted the color of the icons):
    -	media/textures/button_movecenter.png
	  - media/textures/button_redo.png
	  - media/textures/button_undo.png
2. Admin UI by [Freepik](http://www.freepik.com/)
  - http://www.flaticon.com/packs/admin-ui
  - Icons we use(adjusted the color of the icons):
    - media/textures/button_delete.png
