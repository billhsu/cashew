window_width = 800
window_height = 600
backingRatioX = 1
backingRatioY = 1
-- moveCenterMode.checked = true: normal mode
-- moveCenterMode.checked = false: move mode
moveCenterMode = {
    checked=true
}

-- pencilModeEnabled.checked = true: pencil mode
-- pencilModeEnabled.checked = false: line mode
pencilModeEnabled = {
    checked=true
}
