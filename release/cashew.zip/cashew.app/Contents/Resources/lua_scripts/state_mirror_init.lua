mirrorXStatus = {
  checked=false
}
mirrorYStatus = {
  checked=false
}
mirrorZStatus = {
  checked=false
}
